//
//  MoonViewController1.m
//  yu
//
//  Created by 于国文 on 2016/11/11.
//  Copyright © 2016年 SellonLive. All rights reserved.
//

#import "MoonViewController1.h"

#import "GWWaveRippleView.h"

@interface MoonViewController1 ()

@property (nonatomic, strong) GWWaveRippleView *waveRippleView;
@property (nonatomic, strong) UIButton *exchangeAnimationStatusButton;

@end

@implementation MoonViewController1

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor blackColor];
    self.waveRippleView = [[GWWaveRippleView alloc] initWithTintColor:[UIColor yellowColor] minRadius:50 waveCount:5 timeInterval:2 duration:6];
    self.waveRippleView.frame = CGRectMake(20, 100, 300, 300);
    self.exchangeAnimationStatusButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    self.exchangeAnimationStatusButton.frame = CGRectMake(100, 450, 100, 44);
    
    [[self exchangeAnimationStatusButton] setTitle:@"开始" forState:UIControlStateNormal];
    [[self exchangeAnimationStatusButton] setTitle:@"停止" forState:UIControlStateSelected];
    [[self exchangeAnimationStatusButton] setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [self exchangeAnimationStatusButton].backgroundColor = [UIColor grayColor];
    [[self exchangeAnimationStatusButton] addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
    [[self view]addSubview:[self waveRippleView]];
    [[self view] addSubview:[self exchangeAnimationStatusButton]];
}

- (void)buttonClick:(UIButton *)btn
{
    btn.selected = ![btn isSelected];
    if ([btn isSelected]) {
        [[self waveRippleView] startAnimating];
    }else
    {
        
        [[self waveRippleView] stopAnimating];
    }
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
