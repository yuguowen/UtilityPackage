//
//  GWWaveRippleView.h
//  yu
//
//  Created by 于国文 on 2016/11/11.
//  Copyright © 2016年 SellonLive. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GWWaveRippleView : UIView


@property (nonatomic, strong, readonly) UIColor *tintColor;

@property (nonatomic, assign, readonly) NSTimeInterval timeInterval;

@property (nonatomic, assign, readonly) NSTimeInterval duration;

@property (nonatomic, assign, readonly) NSInteger waveCount;

@property (nonatomic, assign, readonly) CGFloat minRadius;

@property (nonatomic, assign, readonly) BOOL animating;

- (instancetype)initWithTintColor:(UIColor *)tintColor minRadius:(CGFloat)minRadius waveCount:(NSInteger)waveCount timeInterval:(NSTimeInterval)timeInterval duration:(NSTimeInterval)duration;

- (void)startAnimating;
- (void)stopAnimating;


@end
