//
//  UIViewController+MBShow.h
//  ManTu
//
//  Created by 于国文 on 16/8/15.
//  Copyright © 2016年 GongBJ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (MBShow)

- (void) showToastWithMessage:(NSString *)message;

@end

