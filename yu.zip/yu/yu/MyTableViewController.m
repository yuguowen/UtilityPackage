//
//  MyTableViewController.m
//  yu
//
//  Created by 于国文 on 2016/10/27.
//  Copyright © 2016年 SellonLive. All rights reserved.
//

#import "MyTableViewController.h"
#import "GWSubTagTableViewCell.h"
#import "GWSubTagItem.h"
#import <MJExtension/MJExtension.h>
#import "UIViewController+MBShow.h"
#import "MHNetwrok.h"




#import "myViewController.h"

@interface MyTableViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) NSArray *tags;

@end


@implementation MyTableViewController

/** cell的循环利用标识 */
static NSString * const XMGTagCellId = @"tag";

- (void)viewDidLoad {
    [super viewDidLoad];
    [self loadnet];
    [self setupTable];
    self.title = @"推荐标签";
      }
- (void)setupTable
{
self.tableView.backgroundColor = XMGColor(220, 220, 221);
    // 设置行高
    self.tableView.rowHeight = 70;
    
    // 去掉系统自带的分割线
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    // 注册cell
    [self.tableView registerNib:[UINib nibWithNibName:NSStringFromClass([GWSubTagTableViewCell class]) bundle:nil] forCellReuseIdentifier:XMGTagCellId];
}



-(void)loadnet
{
    NSString *path = @"http://api.budejie.com/api/api_open.php";
    NSDictionary *params = @{
                             @"a":@"tag_recommend",
                             @"action":@"sub",
                             @"c":@"topic"
                             };
    [MHNetworkManager getRequstWithURL:path params:params successBlock:^(NSDictionary *returnData) {
        
        
        
        _tags = [GWSubTagItem mj_objectArrayWithKeyValuesArray:returnData];
        [self.tableView reloadData];
        
    } failureBlock:^(NSError *error) {
        // 如果是取消了任务，就不算请求失败，就直接返回
        if (error.code == NSURLErrorCancelled) return;
        
        if (error.code == NSURLErrorTimedOut) {
            // 关闭弹框
            [self showToastWithMessage:@"加载标签数据超时，请稍后再试！"];
        } else {
            // 关闭弹框
            [self showToastWithMessage:@"加载标签数据失败"];
        }

        
        
    } showHUD:NO];
}


#pragma mark - Table view data source
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.tags.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
 
    GWSubTagTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:XMGTagCellId];
    
    cell.tagModel = self.tags[indexPath.row];
    
    return cell;
   
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.row == 0) {
//        [self showToastWithMessage:@"你点击了第一个cell"];
        myViewController *myViewControllerTest = [[myViewController alloc] init];
        [self.navigationController pushViewController:myViewControllerTest animated:YES];
      }
    else
    {
    
        [self showToastWithMessage:@"你没有点击第一个cell"];
    }
}

@end
