//
//  UIImage+GWAntialias.h
//  yu
//
//  Created by 于国文 on 2016/10/27.
//  Copyright © 2016年 SellonLive. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (GWAntialias)
// 返回一张抗锯齿图片
// 本质：在图片生成一个透明为1的像素边框
- (UIImage *)imageAntialias;

@end
