module Ovpnmcgen
  VERSION = "0.5.0"
  SUMMARY = "An OpenVPN iOS Configuration Profile (.mobileconfig) Utility"
end
