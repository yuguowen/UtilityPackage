//
//  myViewController.m
//  yu
//
//  Created by 于国文 on 2016/11/11.
//  Copyright © 2016年 SellonLive. All rights reserved.
//

#import "myViewController.h"
#import "UIBarButtonItem+GWExtension.h"
#import "SettingViewController.h"
#import "MoonViewController1.h"

@interface myViewController ()

@end

@implementation myViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    [self setUpNav];
//    [self initUI];
    [self loadNet];
 }

- (void)setUpNav
{

    self.navigationItem.title = @"我的界面";
    UIBarButtonItem *settingButton = [UIBarButtonItem itemWithImage:[UIImage imageNamed:@"mine-setting-iconN"] selImage:[UIImage imageNamed:@"mine-setting-iconN"] targer:self action:@selector(settingClick:)];
    UIBarButtonItem *moonItem = [UIBarButtonItem itemWithImage:[UIImage imageNamed:@"mine-setting-iconN"] selImage:[UIImage imageNamed:@"mine-setting-iconN"] targer:self action:@selector(moonCliclk:)];
//    self.navigationItem.leftBarButtonItem = settingButton;
//    self.navigationItem.rightBarButtonItem = moonItem;
    self.navigationItem.rightBarButtonItems = @[settingButton, moonItem];

}
- (void)initUI
{
    UIView *view = [[UIView alloc] init];
    view.backgroundColor = [UIColor grayColor];
    view.frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height);
    [self.view addSubview:view];
  }
- (void)settingClick:(UIButton *)btn
{
     SettingViewController *settingViewController = [[SettingViewController alloc] init];
    [self.navigationController pushViewController:settingViewController animated:YES];
}
- (void)moonCliclk:(UIButton *)btn
{
    GWLog(@"你好");
    MoonViewController1 *moonViewController = [[MoonViewController1 alloc] init];
    [self.navigationController pushViewController:moonViewController animated:YES];
 
 }
- (void)loadNet
{
NSString *path = @"http://api.budejie.com/api/api_open.php" ;
    NSDictionary *params = @{
                             @"a":@"square",
                             @"c":@"topic",
                             };
    [MHNetworkManager getRequstWithURL:path params:params successBlock:^(NSDictionary *returnData) {
        
    } failureBlock:^(NSError *error) {
        
    } showHUD:NO];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
