//
//  GWSubTagItem.h
//  yu
//
//  Created by 于国文 on 2016/10/27.
//  Copyright © 2016年 SellonLive. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GWSubTagItem : NSObject
/** 图片 */
@property (nonatomic, copy) NSString *image_list;
/** 订阅数 */
@property (nonatomic, assign) NSInteger sub_number;
/** 名字 */
@property (nonatomic, copy) NSString *theme_name;

@end
