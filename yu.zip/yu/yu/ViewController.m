//
//  ViewController.m
//  yu
//
//  Created by 于国文 on 2016/10/26.
//  Copyright © 2016年 SellonLive. All rights reserved.
//

#import "ViewController.h"
#import "MyTableViewController.h"
#define KScreenW [UIScreen mainScreen].bounds.size.width
#define KSCreenH [UIScreen mainScreen].bounds.size.height

@interface ViewController ()


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.title = [NSString stringWithFormat:@"首页"];
//    [self initUI];
}

- (void)initUI

{
    UIView *bgView = [[UIView alloc] init];
    bgView.backgroundColor = [UIColor redColor];
    bgView.frame = CGRectMake(0, 0,KScreenW,KSCreenH );
    [self.view addSubview:bgView];
    UIButton *btn = [[UIButton alloc] init];
    CGFloat padding = 50;
    CGFloat X =  KScreenW *0.5 - padding;
    CGFloat Y =  KSCreenH *0.5 - padding;
    
    btn.frame = CGRectMake(X, Y, padding *2, padding *2);
    btn.backgroundColor = [UIColor greenColor];
    [btn addTarget:self action:@selector(nextStepButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    [btn setTintColor:[UIColor blackColor]];
    [bgView addSubview:btn];

}
- (IBAction)nextStepButtonClick:(UIButton *)sender {
    NSLog(@"你点击了跳转下一个界面");
    MyTableViewController *myTableViewController = [[MyTableViewController alloc] init];
    [self.navigationController pushViewController:myTableViewController animated:YES];
}

@end
