//
//  UIBarButtonItem+GWExtension.h
//  yu
//
//  Created by 于国文 on 2016/11/11.
//  Copyright © 2016年 SellonLive. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIBarButtonItem (GWExtension)

+ (instancetype)itemWithImage:(NSString *)image highImage:(NSString *)highImage target:(id)target action:(SEL)action;


+ (instancetype)itemWithImage:(UIImage *)image selImage:(UIImage *)selImage targer:(id)target action:(SEL)action;

@end
