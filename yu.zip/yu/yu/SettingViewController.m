//
//  SettingViewController.m
//  yu
//
//  Created by 于国文 on 2016/11/11.
//  Copyright © 2016年 SellonLive. All rights reserved.
//

#import "SettingViewController.h"
#define kScreenW    [UIScreen mainScreen].bounds.size.width
#define kScreenH    [UIScreen mainScreen].bounds.size.height
@interface SettingViewController ()

@end

@implementation SettingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self initUI];
}
- (void)initUI
{

    UIView *bgView = [[UIView alloc] init];
    bgView.backgroundColor = [UIColor redColor];
    bgView.frame = CGRectMake(0, 0,kScreenW,kScreenH );
    [self.view addSubview:bgView];
    UIButton *btn = [[UIButton alloc] init];
    btn.backgroundColor = [UIColor greenColor];
    btn.frame = CGRectMake(0, 100, kScreenH, 200);
    [btn setTitle:@"点我返回上个界面" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    [bgView addSubview:btn];
  }
- (void)btnClick :(UIButton *)btn
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
