//
//  GWSubTagTableViewCell.m
//  yu
//
//  Created by 于国文 on 2016/10/27.
//  Copyright © 2016年 SellonLive. All rights reserved.
//

#import "GWSubTagTableViewCell.h"
#import "GWSubTagItem.h"
#import <UIImageView+WebCache.h>



@interface GWSubTagTableViewCell  ()
@property (weak, nonatomic) IBOutlet UIImageView *iconImageView;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *numberLabel;


@end

@implementation GWSubTagTableViewCell
/**
 * 重写这个方法的目的：拦截cell的frame设置
 */
- (void)setFrame:(CGRect)frame
{
    frame.size.height -= 1;
    
    [super setFrame:frame];
}


- (void)awakeFromNib {
    [super awakeFromNib];
    _iconImageView.layer.masksToBounds = YES;
    _iconImageView.layer.cornerRadius = 30.0f;
}

- (void)setTagModel:(GWSubTagItem *)tagModel
{

    _tagModel = tagModel;
    
    // 设置头像
    [self.iconImageView sd_setImageWithURL:[NSURL URLWithString:tagModel.image_list] placeholderImage:nil];
    
    self.nameLabel.text = tagModel.theme_name;
    
    // 订阅数
    if (tagModel.sub_number >= 10000) {
        self.numberLabel.text = [NSString stringWithFormat:@"%.1f万人订阅", tagModel.sub_number / 10000.0];
    } else {
        self.numberLabel.text = [NSString stringWithFormat:@"%zd人订阅", tagModel.sub_number];
    }
  }

@end
